from datetime import date
from flask import Flask, render_template, request, url_for, redirect
import dbMethods
import hashlib
app = Flask('app')

@app.route('/')
def hello_world():
  #dbMethods.createTables()
  #dbMethods.populateCourses()
  #dbMethods.populateLessons()
  #dbMethods.populateProgress()

  #dbMethods.populateUsers() #// šito populatot tikai debugging nolūkos

  
  return render_template ("index.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
  if request.method == 'POST':
    username = request.form['username']
    passwd = request.form['password']
    passwd2 = hashlib.sha256(passwd.encode())
    password = passwd2.hexdigest()
    print(username)
    print(password)
    userExists = dbMethods.checkIfUserExists(username, password)
    if userExists:
      if username == 'admin' and password == '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918':
        return redirect(url_for('mainpage'))
        
      else:
        return redirect(url_for('user_page'))
    else:
      return render_template("login.html")
  return render_template ("login.html")
@app.route('/register', methods=["GET", "POST"])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = hashlib.sha256(request.form['password'].encode()).hexdigest()
        email = request.form['email']
        class_num = request.form['class']
        subclass = request.form['subclass']
        birthdate = request.form['birthdate']
        description = request.form['description']

        # Check if user already exists
        user_exists = dbMethods.checkIfUserExists(username, password)
        if user_exists:
            return redirect(url_for('login'))

        # Register new user
        dbMethods.register(username, password, email, class_num, subclass, birthdate, description)
        return redirect(url_for('mainpage'))
    return render_template("register.html")
  
@app.route('/page')
def user_page():
  users = dbMethods.showAllUsers()
  sweets = dbMethods.showAllCourses()
  warehouse = dbMethods.showAllLessons()
  klienti = dbMethods.showAllProgress()
  return render_template("page.html", p1=users, p2=sweets, p3=warehouse, p4=klienti)


@app.route('/mainpage')
def mainpage():
  courseID = request.args.get('courseid')
  userID = request.args.get('id')
  warID = request.args.get('warid')
  clientID = request.args.get('clientid')
  orderID = request.args.get('orderid')
  if userID is not None:
    dbMethods.deleteUserByID(userID)
    return redirect('mainpage')
  elif courseID is not None:
    dbMethods.deleteSweetsByID(courseID)
    return redirect('mainpage')
  elif warID is not None:
    dbMethods.deleteWarehouseByID(warID)
    return redirect('mainpage')
  elif clientID is not None:
    dbMethods.deleteClientByID(clientID)
    return redirect('mainpage')
  elif orderID is not None:
    dbMethods.deleteOrderByID(orderID)
    return redirect('mainpage')
  else:
    users = dbMethods.showAllUsers()
    sweets = dbMethods.showAllCourses()
    warehouse = dbMethods.showAllLessons()
    klienti = dbMethods.showAllProgress()
    return render_template("mainpage.html", p1=users, p2=sweets, p3=warehouse, p4=klienti)
  
  
#edit, delete, add user#
@app.route('/edituser',methods=["GET","POST"])
def edituser():
  if request.method == 'POST':
    userid = request.form['id']
    username = request.form['username']
    password = request.form['password']
    email = request.form['email']
    notes = request.form['notes']
    isadmin = request.form['isadmin']
    dbMethods.updateUser(userid,username,password,email,notes,isadmin)
    return redirect("mainpage")
  else:
    userID = request.args.get('id')
    user = dbMethods.getUser(userID)
    return render_template("edituser.html",p1=user)

@app.route('/adduser',methods=["GET","POST"])
def adduser():
  if request.method == 'POST':
    username = request.form['username']
    password = request.form['password']
    email = request.form['email']
    notes = request.form['notes']
    isadmin = request.form['isadmin']
    dbMethods.adduser(username,password,email,notes,isadmin)
    return redirect("mainpage")
  else:
    return render_template("adduser.html")


#edit, delete, add Sweets#

@app.route('/editcourse',methods=["GET","POST"])
def editsweets():
  if request.method == 'POST':
    courseid = request.form['courseid']
    name = request.form['name']
    count = request.form['count']
    level = request.form['level']
    desc = request.form['desc']
    dbMethods.updatesweets(courseid,name,count,level,desc)
    return redirect("mainpage")
  else:
    courseID = request.args.get('sweetsid')
    course = dbMethods.getSweets(courseID)
    return render_template("editcourse.html",p2=course)

@app.route('/addcourse',methods=["GET","POST"])
def addcourse():
  if request.method == 'GET':
    return render_template("addcourse.html")
  else:
    name = request.form['name']
    count = request.form['count']
    level = request.form['level']
    desc = request.form['desc']
    dbMethods.addcourse(name,count,level,desc)
    return redirect("mainpage")

#edit, delete, add Warehouse#

@app.route('/editwarehouse',methods=["GET","POST"])
def editwarehouse():
  if request.method == 'POST':
    warehouseid = request.form['warid']
    sweetsid = request.form['sweetsid']
    daudzums = request.form['amount']
    dbMethods.updatewarehouse(warehouseid,sweetsid,daudzums)
    return redirect("mainpage")
  else:
    warehouseID = request.args.get('warid')
    warehouse = dbMethods.getWarehouse(warehouseID)
    return render_template("editwarehouse.html",p3=warehouse)

@app.route('/addwarehouse',methods=["GET","POST"])
def addwarehouse():
  if request.method == 'GET':
    return render_template("addwarehouse.html")
  else:
    sweetsid = request.form['sweetsid']
    daudzums = request.form['amount']
    dbMethods.addwarehouse(sweetsid,daudzums)
    return redirect("mainpage")




#edit, delete, add Clients#

@app.route('/editclient',methods=["GET","POST"])
def editclient():
  if request.method == 'POST':
    clientid = request.form['clientid']
    name = request.form['name']
    info = request.form['info']
    notes = request.form['notes']
    dbMethods.updateclient(clientid,name,info,notes)
    return redirect("mainpage")
  else:
    clientID = request.args.get('clientid')
    klients = dbMethods.getClient(clientID)
    return render_template("editclient.html",p4=klients)


@app.route('/addclient',methods=["GET","POST"])
def addclient():
  if request.method == 'GET':
    return render_template("addclient.html")
  else:
    name = request.form['name']
    info = request.form['info']
    notes = request.form['notes']
    dbMethods.addclient(name,info,notes)
    return redirect("mainpage")




#edit, delete, add Orders#

@app.route('/editorder',methods=["GET","POST"])
def editorder():
  if request.method == 'POST':
    orderid = request.form['orderid']
    clientid = request.form['clientid']
    sweetsid = request.form['sweetsid']
    pasdate = request.form['pasdate']
    izpdate = request.form['izpdate']
    amount = request.form['amount']
    dbMethods.updateOrder(orderid,clientid,sweetsid,pasdate,izpdate,amount)
    return redirect("mainpage")
  else:
    orderID = request.args.get('orderid')
    order = dbMethods.getOrder(orderID)
    return render_template("editorder.html",p5=order)

@app.route('/addorder',methods=["GET","POST"])
def addorder():
  if request.method == 'GET':
    return render_template("addorder.html")
  else:
    clientid = request.form['clientid']
    sweetsid = request.form['sweetsid']
    pasdate = request.form['pasdate']
    izpdate = request.form['izpdate']
    amount = request.form['amount']
    dbMethods.addorder(clientid,sweetsid,pasdate,izpdate,amount)
    return redirect("mainpage")


















































if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)

