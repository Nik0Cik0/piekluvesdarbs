import sqlite3

def createTables():
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  
  SQL_statement1 = """
    CREATE TABLE IF NOT EXISTS Users(
    User_ID INTEGER PRIMARY KEY,
    Username VARCHAR(50) NOT NULL,
    Password VARCHAR(50) NOT NULL,
    Email VARCHAR(50),
    Class INT,
    SubClass VARCHAR(10),
    BirthDate DATE,
    Description VARCHAR(500)
    );
  """
  SQL_statement2 = """
  CREATE TABLE IF NOT EXISTS Courses(
  Course_ID INTEGER PRIMARY KEY,
  Course_Name VARCHAR(100) NOT NULL,
  Hours INT,
  Level VARCHAR(50),
  Description VARCHAR(500)
  );
  """

  # Lessons Table
  SQL_statement3 = """
  CREATE TABLE IF NOT EXISTS Lessons(
  Lesson_ID INTEGER PRIMARY KEY,
  Course_ID INTEGER,
  Lesson_Name VARCHAR(100),
  Lesson_Description VARCHAR(500),
  Practice_Tasks INT,
  FOREIGN KEY (Course_ID) REFERENCES Courses(Course_ID)
  );
  """

  # Progress Table
  SQL_statement4 = """
  CREATE TABLE IF NOT EXISTS Progress(
  Progress_ID INTEGER PRIMARY KEY,
  User_ID INTEGER,
  Lesson_ID INTEGER,
  Description VARCHAR(500)
  );
  """

  c.execute(SQL_statement1)
  c.execute(SQL_statement2)
  c.execute(SQL_statement3)
  c.execute(SQL_statement4)
  conn.commit()
  c.close()
  conn.close()

def populateUsers():
  conn = sqlite3.connect('database.sql', timeout=10)
  c = conn.cursor()

  SQL_statement1 = """
  INSERT INTO Users VALUES (NULL, 'Admin', 'Admin123', 'admin@gmail.com', 12, 'b', '2006-04-12', 'Esmu 18 gadus vecs, Aizraujos ar programmēšanu');
  """
  SQL_statement2 = """
  INSERT INTO Users VALUES (NULL, 'Janis', 'Password123', 'janis@gmail.com', 10, 'a', '2008-05-30', 'Man patīk mācīties jaunas lietas.');
  """
  SQL_statement3 = """
  INSERT INTO Users VALUES (NULL, 'Diana', 'Diana123', 'diana@gmail.com', 11, 'c', '2007-11-22', 'Man ļoti patīk programmēšana.');
  """

  c.execute(SQL_statement1)
  c.execute(SQL_statement2)
  c.execute(SQL_statement3)
  conn.commit()
  c.close()
  conn.close()

def populateCourses():
  conn = sqlite3.connect('database.sql', timeout=10)
  c = conn.cursor()

  SQL_statement1 = """
  INSERT INTO Courses VALUES (NULL, 'Python', 10, 'Iesācējiem', 'Ideāls kurss bez iepriekšējām zināšanām.');
  """
  SQL_statement2 = """
  INSERT INTO Courses VALUES (NULL, 'JavaScript', 12, 'Vidējam līmenim', 'Padziļināta mācīšanās par JavaScript.');
  """
  SQL_statement3 = """
  INSERT INTO Courses VALUES (NULL, 'SQL', 8, 'Iesācējiem', 'Ievads datubāzu pārvaldībā.');
  """

  c.execute(SQL_statement1)
  c.execute(SQL_statement2)
  c.execute(SQL_statement3)
  conn.commit()
  c.close()
  conn.close()

def populateLessons():
  conn = sqlite3.connect('database.sql', timeout=10)
  c = conn.cursor()

  SQL_statement1 = """
  INSERT INTO Lessons VALUES (NULL, 1, 'Python pamati', 'Šajā stundā tiks apgūtas Python pamatfunkcijas.', 3);
  """
  SQL_statement2 = """
  INSERT INTO Lessons VALUES (NULL, 1, 'OOP Python', 'Ievads objektorientētā programmēšanā Python.', 4);
  """
  SQL_statement3 = """
  INSERT INTO Lessons VALUES (NULL, 2, 'JavaScript pamati', 'JavaScript sintakse un pamatkoncepcijas.', 2);
  """

  c.execute(SQL_statement1)
  c.execute(SQL_statement2)
  c.execute(SQL_statement3)
  conn.commit()
  c.close()
  conn.close()

def populateProgress():
  conn = sqlite3.connect('database.sql', timeout=10)
  c = conn.cursor()

  SQL_statement1 = """
  INSERT INTO Progress VALUES (NULL, 1, 1, 'Izpildīti 13/14');
  """
  SQL_statement2 = """
  INSERT INTO Progress VALUES (NULL, 2, 2, 'Izpildīti 5/10');
  """
  SQL_statement3 = """
  INSERT INTO Progress VALUES (NULL, 3, 3, 'Izpildīti 7/8');
  """

  c.execute(SQL_statement1)
  c.execute(SQL_statement2)
  c.execute(SQL_statement3)
  conn.commit()
  c.close()
  conn.close()

def checkIfUserExists(username,password):
  userExists = False
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement1 = """
    SELECT * FROM Users WHERE Username = ? AND Password = ?;
  """
  c.execute(SQL_statement1,(username,password))
  result = c.fetchone()
  if result != None:
    userExists = True
  c.close()
  conn.close()
  return userExists

def register(username, password, email, class_num, subclass, birthdate, description):
  conn = sqlite3.connect('database.sql', timeout=10)
  c = conn.cursor()
  SQL_statement = """
      INSERT INTO Users (Username, Password, Email, Class, SubClass, BirthDate, Description)
      VALUES (?, ?, ?, ?, ?, ?, ?);
  """
  c.execute(SQL_statement, (username, password, email, class_num, subclass, birthdate, description))
  conn.commit()
  c.close()
  conn.close()
  return True





#Funkcija, kas atlasa VISUS lietotājus no DB
#Funkcija, kas atlasa VISUS lietotājus no DB
#Funkcija, kas atlasa VISUS lietotājus no DB
#Funkcija, kas atlasa VISUS lietotājus no DB
#Funkcija, kas atlasa VISUS lietotājus no DB



def showAllUsers():
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement1 = """
    SELECT * FROM Users;
  """
  c.execute(SQL_statement1)
  result = c.fetchall()
  c.close()
  conn.close()
  return result
  
def showAllCourses():
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement1 = """
    SELECT * FROM Courses;
  """
  c.execute(SQL_statement1)
  result = c.fetchall()
  c.close()
  conn.close()
  return result
  
def showAllLessons():
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement1 = """
    SELECT * FROM Lessons;
  """
  c.execute(SQL_statement1)
  result = c.fetchall()
  c.close()
  conn.close()
  return result
  
def showAllProgress():
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement1 = """
    SELECT * FROM Progress;
  """
  c.execute(SQL_statement1)
  result = c.fetchall()
  c.close()
  conn.close()
  return result      

  #Pievienot/Dzest/Labot User#

def getUser(userID):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement1 = """
    SELECT * FROM Users WHERE User_ID = ?;
  """
  c.execute(SQL_statement1,(userID))
  result = c.fetchone()
  c.close()
  conn.close()
  return result

def updateUser(userid,username,password,email,notes,isadmin):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement1 = """
    UPDATE Users SET Username = ?, Password = ?, Email = ?, Notes = ?, IsAdmin = ? WHERE User_ID = ?;
  """
  c.execute(SQL_statement1,(username,password,email,notes,isadmin,userid))
  conn.commit()
  c.close()
  conn.close()
  return True

def deleteUserByID(userID):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement1 = """
    DELETE FROM Users WHERE User_ID = ?;
  """
  c.execute(SQL_statement1,(userID))
  conn.commit()
  c.close()
  conn.close()
  return True

def adduser(username,password,email,notes,isadmin):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement1 = """
    INSERT INTO Users VALUES (NULL,?,?,?,?,?);
  """
  c.execute(SQL_statement1,(username,password,email,notes,isadmin))
  conn.commit()
  c.close()
  conn.close()
  return True


  #Pievienot/Dzest/Labot sweets#

def getSweets(sweetsID):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement2 = """
    SELECT * FROM Courses WHERE Course_ID = ?;
  """
  c.execute(SQL_statement2,(sweetsID))
  result = c.fetchone()
  c.close()
  conn.close()
  return result

def updatesweets(courseid,name,count,level,desc):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement2 = """
    UPDATE Courses SET Course_Name = ?, Hours = ?, Level = ?, Description = ? WHERE Course_ID = ?;
  """
  c.execute(SQL_statement2,(name,count,level,desc,courseid))
  conn.commit()
  c.close()
  conn.close()
  return True

def deleteSweetsByID(sweetsID):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement2 = """
    DELETE FROM Courses WHERE Course_ID = ?;
  """
  c.execute(SQL_statement2,(sweetsID))
  conn.commit()
  c.close()
  conn.close()
  return True

def addcourse(name,count,level,desc):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement2 = """
    INSERT INTO Courses VALUES (NULL,?,?,?,?);
  """
  c.execute(SQL_statement2,(name,count,level,desc))
  conn.commit()
  c.close()
  conn.close()
  return True


#Pievienot/Dzest/Labot Warehouse#

def getWarehouse(warID):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement3 = """
    SELECT * FROM Warehouse WHERE Warehouse_ID = ?;
  """
  c.execute(SQL_statement3,(warID))
  result = c.fetchone()
  c.close()
  conn.close()
  return result

def updatewarehouse(warid,sweetsid,daudzums):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement3 = """
    UPDATE Warehouse SET Sweets_ID = ?, Amount = ? WHERE Warehouse_ID = ?;
  """
  c.execute(SQL_statement3,(sweetsid, daudzums, warid))
  conn.commit()
  c.close()
  conn.close()
  return True

def deleteWarehouseByID(warID):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement3 = """
    DELETE FROM Warehouse WHERE Warehouse_ID = ?;
  """
  c.execute(SQL_statement3,(warID))
  conn.commit()
  c.close()
  conn.close()
  return True

def addwarehouse(sweetsid,daudzums):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement3 = """
    INSERT INTO Warehouse VALUES (NULL,?,?);
  """
  c.execute(SQL_statement3,(sweetsid,daudzums))
  conn.commit()
  c.close()
  conn.close()
  return True


#Pievienot/Dzest/Labot Clients#

def getClient(clientID):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement4 = """
    SELECT * FROM Clients WHERE Client_ID = ?;
  """
  c.execute(SQL_statement4,(clientID))
  result = c.fetchone()
  c.close()
  conn.close()
  return result

def updateclient(clientid,name,info,notes):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement4 = """
    UPDATE Clients SET Company_Name = ?, Contact_Info = ?, Notes = ? WHERE Client_ID = ?;
  """
  c.execute(SQL_statement4,(name,info,notes,clientid))
  conn.commit()
  c.close()
  conn.close()
  return True


def deleteClientByID(clientID):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement4 = """
    DELETE FROM Clients WHERE Client_ID = ?;
  """
  c.execute(SQL_statement4,(clientID))
  conn.commit()
  c.close()
  conn.close()
  return True



def addclient(name,info,notes):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement4 = """
    INSERT INTO Clients VALUES (NULL,?,?,?);
  """
  c.execute(SQL_statement4,(name,info,notes))
  conn.commit()
  c.close()
  conn.close()
  return True

#Pievienot/Dzest/Labot Orders#


def getOrder(orderID):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement5 = """
    SELECT * FROM Orders WHERE Order_ID = ?;
  """
  c.execute(SQL_statement5,(orderID))
  result = c.fetchone()
  c.close()
  conn.close()
  return result


def updateOrder(orderid,clientid,sweetsid,pasdate,izpdate,amount):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement5 = """
  UPDATE Orders SET Client_ID = ?, Sweets_ID = ?, Order_date = ?, Shipment_date = ?, Amount = ? WHERE Order_ID = ?;
  """
  c.execute(SQL_statement5,(clientid,sweetsid,pasdate,izpdate,amount,orderid))
  conn.commit()
  c.close()
  conn.close()
  return True

def addorder(clientid,sweetsid,pasdate,izpdate,amount):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement5 = """
    INSERT INTO Orders VALUES (NULL,?,?,?,?,?);
  """
  c.execute(SQL_statement5,(clientid,sweetsid,pasdate,izpdate,amount))
  conn.commit()
  c.close()
  conn.close()
  return True


def deleteOrderByID(orderID):
  conn = sqlite3.connect('database.sql',timeout=10)
  c = conn.cursor()
  SQL_statement5 = """
    DELETE FROM Orders WHERE Order_ID = ?;
  """
  c.execute(SQL_statement5,(orderID))
  conn.commit()
  c.close()
  conn.close()
  return True